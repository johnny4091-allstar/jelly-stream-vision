sub init()
    m.list = m.top.findNode("list")
    m.status = m.top.findNode("status")
    m.video = m.top.findNode("video")
    m.channels = []
    m.start = 0
    m.total = 0
    m.list.observeField("itemFocused", "onFocus")
    m.list.observeField("itemSelected", "onSelect")
    m.video.observeField("state", "onVideoState")
    m.reg = CreateObject("roRegistrySection", "aurora")
    m.token = m.reg.Read("token")
    if m.token = "" then askUser() else loadChannels()
end sub

sub askUser()
    d = CreateObject("roSGNode", "KeyboardDialog")
    d.title = "Aurora username"
    d.buttons = ["Next"]
    d.observeField("buttonSelected", "onUser")
    m.top.dialog = d
end sub

sub onUser()
    m.user = m.top.dialog.text
    d = CreateObject("roSGNode", "KeyboardDialog")
    d.title = "Password"
    d.keyboard.textEditBox.secureMode = true
    d.buttons = ["Sign in"]
    d.observeField("buttonSelected", "onPass")
    m.top.dialog = d
end sub

sub onPass()
    pass = m.top.dialog.text
    m.top.dialog.close = true
    m.status.text = "Signing in..."
    api("login", "POST", FormatJson({ username: m.user, password: pass }), "login")
end sub

sub api(path, method, body, kind)
    t = CreateObject("roSGNode", "ApiTask")
    t.path = path : t.method = method : t.body = body : t.kind = kind : t.token = m.token
    t.observeField("result", "onResult")
    t.control = "RUN"
    m.task = t
end sub

sub loadChannels()
    m.status.text = "Loading channels..."
    api("channels?start=" + m.start.ToStr() + "&limit=100", "GET", "", "channels")
end sub

sub onResult(e)
    r = e.getData()
    if r.code = 401 and r.kind <> "login"
        m.reg.Delete("token") : m.reg.Flush() : m.token = ""
        askUser() : return
    end if
    if not r.ok
        m.status.text = "Something went wrong. Try again."
        if r.kind = "login" then askUser()
        return
    end if
    if r.kind = "login"
        m.token = r.data.token
        m.reg.Write("token", m.token) : m.reg.Flush()
        loadChannels()
    else if r.kind = "channels"
        m.channels = r.data.channels
        m.total = r.data.total
        content = CreateObject("roSGNode", "ContentNode")
        for each c in m.channels
            n = content.createChild("ContentNode")
            n.title = c.number + "   " + c.name
        end for
        m.list.content = content
        last = m.start + m.channels.Count()
        m.status.text = "Channels " + (m.start + 1).ToStr() + "-" + last.ToStr() + " of " + m.total.ToStr()
        m.list.setFocus(true)
        onFocus()
    else if r.kind = "guide"
        txt = ""
        cnt = 0
        for each p in r.data.programs
            if cnt > 0 and cnt < 9 then txt = txt + timeOf(p.start) + "   " + p.name + chr(10)
            cnt = cnt + 1
        end for
        m.top.findNode("guideText").text = txt
    else if r.kind = "stream"
        c = CreateObject("roSGNode", "ContentNode")
        c.url = r.data.url
        c.streamFormat = "hls"
        c.live = true
        c.title = m.current.name
        m.video.content = c
        m.video.visible = true
        m.video.setFocus(true)
        m.video.control = "play"
        m.status.text = ""
    end if
end sub

function timeOf(iso) as string
    d = CreateObject("roDateTime")
    d.FromISO8601String(iso)
    d.ToLocalTime()
    h = d.GetHours() : mi = d.GetMinutes()
    ap = "AM"
    if h >= 12 then ap = "PM"
    h = h mod 12
    if h = 0 then h = 12
    s = mi.ToStr()
    if mi < 10 then s = "0" + s
    return h.ToStr() + ":" + s + " " + ap
end function

sub onFocus()
    i = m.list.itemFocused
    if i < 0 or i >= m.channels.Count() then return
    c = m.channels[i]
    m.top.findNode("logo").uri = c.logo
    m.top.findNode("chName").text = c.number + "  " + c.name
    m.top.findNode("nowName").text = c.now
    m.top.findNode("guideText").text = ""
    api("guide?channelIds=" + c.id, "GET", "", "guide")
end sub

sub onSelect()
    m.current = m.channels[m.list.itemSelected]
    m.status.text = "Tuning " + m.current.name + "..."
    api("stream?id=" + m.current.id, "GET", "", "stream")
end sub

sub onVideoState()
    if m.video.state = "error"
        m.status.text = "This channel couldn't play right now."
        closeVideo()
    end if
end sub

sub closeVideo()
    m.video.control = "stop"
    m.video.visible = false
    m.list.setFocus(true)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if m.video.visible
        if key = "back" then closeVideo() : return true
        if key = "up" or key = "down"
            i = m.list.itemFocused
            if key = "up" then i = i - 1 else i = i + 1
            if i >= 0 and i < m.channels.Count()
                m.list.jumpToItem = i
                m.current = m.channels[i]
                api("stream?id=" + m.current.id, "GET", "", "stream")
            end if
            return true
        end if
        return false
    end if
    if key = "right" and m.start + 100 < m.total then m.start = m.start + 100 : loadChannels() : return true
    if key = "left" and m.start > 0 then m.start = m.start - 100 : loadChannels() : return true
    if key = "options"
        m.reg.Delete("token") : m.reg.Flush() : m.token = "" : askUser() : return true
    end if
    return false
end function
