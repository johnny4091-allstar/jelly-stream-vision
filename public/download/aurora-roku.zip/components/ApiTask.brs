sub init()
    m.top.functionName = "run"
end sub

sub run()
    req = CreateObject("roUrlTransfer")
    req.SetCertificatesFile("common:/certs/ca-bundle.crt")
    req.InitClientCertificates()
    req.SetUrl("https://jelly-stream-vision.lovable.app/api/public/roku/" + m.top.path)
    req.AddHeader("Content-Type", "application/json")
    if m.top.token <> "" then req.AddHeader("Authorization", "Bearer " + m.top.token)
    port = CreateObject("roMessagePort")
    req.SetMessagePort(port)
    if m.top.method = "POST"
        req.AsyncPostFromString(m.top.body)
    else
        req.AsyncGetToString()
    end if
    msg = wait(30000, port)
    out = { kind: m.top.kind, ok: false, code: 0 }
    if type(msg) = "roUrlEvent"
        out.code = msg.GetResponseCode()
        data = ParseJson(msg.GetString())
        if data <> invalid then out.data = data
        out.ok = (out.code = 200)
    end if
    m.top.result = out
end sub
